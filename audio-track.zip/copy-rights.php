	<footer class="main-footer">
        <div class="pull-right hidden-xs"><b>Version</b> 1.0.0 </div>
        <strong>Copyright &copy; 2014-2016 <a href="#">Dashbord LCW</a>.</strong> All rights reserved.
    </footer>
	
    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
        <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
            <li><a href="#control-sidebar-home-tab" data-toggle="tab"><i class="fa fa-home"></i></a></li>
            <li><a href="#control-sidebar-settings-tab" data-toggle="tab"><i class="fa fa-gears"></i></a></li>
        </ul>
    </aside>
  	<!-- /.control-sidebar -->
  	<!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  	<div class="control-sidebar-bg"></div>