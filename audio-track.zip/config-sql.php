<?php
@ob_start();
session_start();
error_reporting(E_ALL);
	
	define('HOST', 'offline');
	
	#echo "--------".dirname(__FILE__);
	
	if(HOST == 'online')
	{
		$serverName	=	'ETQ-TECH-ZAID\MSSQLSERVER_2';
		// Since UID and PWD are not specified in the $connectionInfo array,
		// The connection will be attempted using Windows Authentication.
		//$connectionInfo = array( "Database"=>"etq", "UID"=>"sa", "PWD"=>"Zindagi!@)");
		$connectionInfo = array( "Database"=>"etq");
		$connSQL = sqlsrv_connect( $serverName, $connectionInfo);
		
		if(!$connSQL){
			echo "Connection could not be established.\n";
		    die( print_r( sqlsrv_errors(), true));
		}
		
		define('HOME_URL',"http://etelequote.com/");
		$temp	=	explode("admin",dirname(__FILE__));
		define("HOME_PATH",$temp[0]);
		define('DIR_PATH',HOME_PATH."/");
	}else{
		$serverName	=	'ETQ-TECH-ZAID';
		// Since UID and PWD are not specified in the $connectionInfo array,
		// The connection will be attempted using Windows Authentication.
		$connectionInfo = array( "Database"=>"etq", "UID"=>"sa", "PWD"=>"Zindagi!@)");
		//$connectionInfo = array( "Database"=>"etq");
		$connSQL = sqlsrv_connect( $serverName, $connectionInfo);
		
		if(!$connSQL){
			echo "Connection could not be established.\n";
		    die( print_r( sqlsrv_errors(), true));
		}
		
		define('HOME_URL',"http://localhost:8080/audiotracker/");
		$temp	=	explode("admin",dirname(__FILE__));
		define("HOME_PATH",$temp[0]);
		define('DIR_PATH',HOME_PATH."/");
	}
	
	define("NO_REPLY_EMAIL","info@etelequote.com");
	define("NO_REPLY_NAME","ETQ");
	define("ADMIN_NAME","Zaid");
	define('AJAX_URL',HOME_URL."ajax/");
	
	include_once(DIR_PATH."includes/class.phpmailer.php");
	include_once(DIR_PATH."includes/Zebra_Pagination.php");
	
	$mail		= 	new	PHPMailer();
	$pagination = 	new Zebra_Pagination();
	
	$mail->IsSMTP();
	$mail->IsHTML(true);
	$mail->SMTPAuth = true;
	$mail->Host = "mail.etelequote.com";
	$mail->Port = 26;
	$mail->Username = "info@etelequote.com111";
	$mail->Password = "ZXcv@1234!!";	
			
	//--------------------- Site constant -------------------//
	
	define('SITE_NAME','Web Portal');
	
	define("FILE_PATH",HOME_PATH.trim("uploads/ "," "));
	
	define("FILE_URL",HOME_URL."uploads/");	
		
	//--------------------- Table constant -------------------//
	
	define('TB_ADMIN','admins');
	define('TB_USERDATA','userdata');