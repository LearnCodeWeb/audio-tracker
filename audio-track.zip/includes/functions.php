<?php
/*
	* This is develop by zaid
	* For LCW.
	* version 1.0.1
*/
